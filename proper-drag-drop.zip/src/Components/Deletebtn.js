import React from 'react'

function Deletebtn() {
  return (
    function Deletebtn() {
  return (
    <div id="delete-container" style={{width:100,height:100,backgroundColor:"red"}}>
      Drop here to delete
    </div>
  );
}

  )
}

export default Deletebtn
